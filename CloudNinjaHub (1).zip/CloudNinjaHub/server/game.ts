import { storage } from "./storage";
import { Player, GameState, WebSocketMessage, Platform } from "@shared/schema";
import { addSystemMessage } from "./messages";

// Define platforms
const platforms: Platform[] = [
  // Ground platform
  { x: 0, y: 450, width: 800, height: 50 },
  // Middle platforms
  { x: 100, y: 350, width: 200, height: 20 },
  { x: 500, y: 350, width: 200, height: 20 },
  // Higher platforms
  { x: 300, y: 250, width: 200, height: 20 },
  { x: 150, y: 150, width: 150, height: 20 },
  { x: 500, y: 150, width: 150, height: 20 }
];

// Game physics constants
const GRAVITY = 0.5;
const JUMP_FORCE = -12;
const MOVEMENT_SPEED = 5;

// Game state
let gameState: GameState = {
  players: [],
  platforms,
  gravity: GRAVITY,
  started: false,
  currentTagger: null
};

// Game loop
let gameLoopInterval: NodeJS.Timeout | null = null;

export async function addPlayer(userId: number): Promise<void> {
  const user = await storage.getUser(userId);
  if (!user) return;
  
  // Check if player already exists
  const existingPlayerIndex = gameState.players.findIndex(p => p.id === userId);
  if (existingPlayerIndex !== -1) return;
  
  // Place player on the ground platform
  const groundPlatform = platforms[0];
  const x = Math.floor(Math.random() * (groundPlatform.width - 50)) + groundPlatform.x;
  const y = groundPlatform.y - 50; // Place on top of the platform
  
  const newPlayer: Player = {
    id: userId,
    username: user.username,
    characterId: user.characterId,
    avatar: user.avatar,
    x,
    y,
    velocityY: 0,
    velocityX: 0,
    isJumping: false,
    direction: 'idle',
    points: 0,
    isIt: false
  };
  
  gameState.players.push(newPlayer);
  
  // Start game loop if not already running
  if (!gameLoopInterval) {
    startGameLoop();
  }
  
  await broadcastGameState();
  
  await addSystemMessage(`${user.username} joined the game.`);
}

export async function removePlayer(userId: number): Promise<void> {
  const playerIndex = gameState.players.findIndex(p => p.id === userId);
  if (playerIndex === -1) return;
  
  const player = gameState.players[playerIndex];
  gameState.players.splice(playerIndex, 1);
  
  // If the removed player was the tagger, reset the game
  if (gameState.currentTagger === userId) {
    if (gameState.players.length > 1) {
      await selectRandomTagger();
    } else {
      gameState.started = false;
      gameState.currentTagger = null;
    }
  }
  
  await broadcastGameState();
  
  await addSystemMessage(`${player.username} left the game.`);
}

export async function movePlayer(userId: number, x: number, y: number): Promise<void> {
  // Mouse-click movement is disabled in favor of WASD controls
  // This function is kept for backward compatibility
}

export async function handleKeyPress(userId: number, key: string): Promise<void> {
  const player = gameState.players.find(p => p.id === userId);
  if (!player) return;
  
  switch (key.toLowerCase()) {
    case 'w':
      // Jump only if player is on the ground (not already jumping)
      if (!player.isJumping) {
        player.velocityY = JUMP_FORCE;
        player.isJumping = true;
      }
      break;
    case 'a':
      player.velocityX = -MOVEMENT_SPEED;
      player.direction = 'left';
      break;
    case 'd':
      player.velocityX = MOVEMENT_SPEED;
      player.direction = 'right';
      break;
    case 's':
      // Optionally implement a crouch or drop-through-platform mechanic
      break;
  }
}

export async function handleKeyRelease(userId: number, key: string): Promise<void> {
  const player = gameState.players.find(p => p.id === userId);
  if (!player) return;
  
  switch (key.toLowerCase()) {
    case 'a':
      if (player.velocityX < 0) {
        player.velocityX = 0;
        player.direction = 'idle';
      }
      break;
    case 'd':
      if (player.velocityX > 0) {
        player.velocityX = 0;
        player.direction = 'idle';
      }
      break;
  }
}

async function checkForTags(tagger: Player): Promise<void> {
  for (const player of gameState.players) {
    if (player.id !== tagger.id) {
      const dx = tagger.x - player.x;
      const dy = tagger.y - player.y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      
      if (distance < 50) { // Tagging distance
        // Update tag status
        tagger.isIt = false;
        player.isIt = true;
        gameState.currentTagger = player.id;
        
        // Update score
        tagger.points += 1;
        
        await broadcastGameState();
        
        const wsMessage: WebSocketMessage = {
          type: 'PLAYER_TAGGED',
          payload: {
            taggerId: tagger.id,
            taggedId: player.id
          }
        };
        
        storage.broadcastToAll(wsMessage);
        
        await addSystemMessage(`${tagger.username} tagged ${player.username} and earned a point!`);
        
        break;
      }
    }
  }
}

export async function startGame(): Promise<void> {
  if (gameState.players.length < 2) {
    await addSystemMessage("Need at least 2 players to start the game.");
    return;
  }
  
  gameState.started = true;
  
  await selectRandomTagger();
  
  await broadcastGameState();
  
  const tagger = gameState.players.find(p => p.id === gameState.currentTagger);
  if (tagger) {
    await addSystemMessage(`Game started! ${tagger.username} is it!`);
  }
}

export async function resetGame(): Promise<void> {
  gameState.started = false;
  gameState.currentTagger = null;
  
  // Reset players to starting positions on the ground platform
  const groundPlatform = platforms[0];
  for (const player of gameState.players) {
    player.points = 0;
    player.isIt = false;
    player.velocityX = 0;
    player.velocityY = 0;
    player.isJumping = false;
    player.direction = 'idle';
    player.x = Math.floor(Math.random() * (groundPlatform.width - 50)) + groundPlatform.x;
    player.y = groundPlatform.y - 50; // Place on top of the platform
  }
  
  await broadcastGameState();
  
  await addSystemMessage("Game has been reset.");
}

async function selectRandomTagger(): Promise<void> {
  const randomIndex = Math.floor(Math.random() * gameState.players.length);
  
  for (let i = 0; i < gameState.players.length; i++) {
    gameState.players[i].isIt = i === randomIndex;
  }
  
  gameState.currentTagger = gameState.players[randomIndex].id;
}

export async function broadcastGameState(): Promise<void> {
  const wsMessage: WebSocketMessage = {
    type: 'GAME_STATE',
    payload: gameState
  };
  
  storage.broadcastToAll(wsMessage);
}

export function getGameState(): GameState {
  return { ...gameState };
}

// Game physics loop
function startGameLoop(): void {
  if (gameLoopInterval) {
    clearInterval(gameLoopInterval);
  }
  
  gameLoopInterval = setInterval(updatePhysics, 1000 / 60); // 60 FPS
}

// Stop game loop when no players are left
function stopGameLoop(): void {
  if (gameLoopInterval) {
    clearInterval(gameLoopInterval);
    gameLoopInterval = null;
  }
}

// Physics update function
async function updatePhysics(): Promise<void> {
  // Skip if no players
  if (gameState.players.length === 0) {
    stopGameLoop();
    return;
  }

  let needsUpdate = false;
  
  // Update each player's position based on physics
  for (const player of gameState.players) {
    // Apply gravity
    player.velocityY += GRAVITY;
    
    // Apply velocities to position
    const oldX = player.x;
    const oldY = player.y;
    
    player.x += player.velocityX;
    player.y += player.velocityY;
    
    // Boundary checks
    player.x = Math.max(0, Math.min(player.x, 800 - 40)); // 40 is player width
    
    // Check platform collisions
    player.isJumping = true; // Assume in air unless we find a platform below
    
    for (const platform of gameState.platforms) {
      // Check if player is standing on this platform
      if (player.velocityY >= 0 && // Moving downward or stationary
          player.x + 30 > platform.x && player.x < platform.x + platform.width && // Horizontally within platform
          oldY + 40 <= platform.y && player.y + 40 >= platform.y) { // Was above, now touching or below
        
        player.y = platform.y - 40; // Place on top of platform
        player.velocityY = 0;
        player.isJumping = false;
      }
    }
    
    // Check if player fell off the bottom
    if (player.y > 600) {
      // Reset to ground platform
      const groundPlatform = platforms[0];
      player.x = Math.floor(Math.random() * (groundPlatform.width - 50)) + groundPlatform.x;
      player.y = groundPlatform.y - 50;
      player.velocityY = 0;
      player.isJumping = false;
    }
    
    // Check if we need to broadcast an update
    if (oldX !== player.x || oldY !== player.y) {
      needsUpdate = true;
    }
    
    // Check for tags if game is started
    if (gameState.started && player.isIt) {
      await checkForTags(player);
    }
  }
  
  // Broadcast game state if any player moved
  if (needsUpdate) {
    await broadcastGameState();
  }
}
