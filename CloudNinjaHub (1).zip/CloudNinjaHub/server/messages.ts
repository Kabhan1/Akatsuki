import { storage } from "./storage";
import { Message, WebSocketMessage } from "@shared/schema";
import { customAlphabet } from "nanoid";

const nanoid = customAlphabet("1234567890abcdef", 10);

// Store messages in memory
const messages: Message[] = [];

// Add a system welcome message
messages.push({
  id: nanoid(),
  sender: "system",
  senderName: "System",
  senderAvatar: "",
  text: "Welcome to the Akatsuki chat room. Messages will appear here.",
  timestamp: new Date().toISOString(),
  isSystem: true
});

export async function addMessage(message: Omit<Message, "id">): Promise<Message> {
  const newMessage: Message = {
    ...message,
    id: nanoid(),
    timestamp: new Date().toISOString()
  };
  
  messages.push(newMessage);
  
  // Keep only the last 100 messages
  if (messages.length > 100) {
    messages.shift();
  }
  
  return newMessage;
}

export async function addSystemMessage(text: string): Promise<Message> {
  return addMessage({
    sender: "system",
    senderName: "System",
    senderAvatar: "",
    text,
    isSystem: true
  });
}

export async function getMessages(): Promise<Message[]> {
  return [...messages];
}

export async function handleChatMessage(userId: number, messageText: string): Promise<void> {
  const user = await storage.getUser(userId);
  if (!user) return;
  
  const message = await addMessage({
    sender: user.username,
    senderName: user.username,
    senderAvatar: user.avatar,
    text: messageText
  });
  
  const wsMessage: WebSocketMessage = {
    type: 'CHAT_MESSAGE',
    payload: message
  };
  
  storage.broadcastToAll(wsMessage);
}
