import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { loginUserSchema } from "@shared/schema";
import { addPlayer, removePlayer, movePlayer, handleKeyPress, handleKeyRelease, startGame, resetGame, getGameState } from "./game";
import { handleChatMessage, getMessages } from "./messages";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);
  
  // Create WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Handle WebSocket connections
  wss.on('connection', (ws: WebSocket) => {
    let userId: number | null = null;
    
    ws.on('message', async (message: string) => {
      try {
        const data = JSON.parse(message);
        
        if (data.type === 'AUTH' && data.userId) {
          userId = Number(data.userId);
          storage.addClient(userId, ws);
          await addPlayer(userId);
          
          // Send initial data to the connected client
          const messages = await getMessages();
          ws.send(JSON.stringify({
            type: 'INITIAL_DATA',
            payload: {
              messages,
              gameState: getGameState()
            }
          }));
        } else if (userId) {
          // Process message based on its type
          switch (data.type) {
            case 'CHAT_MESSAGE':
              await handleChatMessage(userId, data.payload);
              break;
            case 'PLAYER_MOVE':
              await movePlayer(userId, data.payload.x, data.payload.y);
              break;
            case 'GAME_START':
              await startGame();
              break;
            case 'GAME_RESET':
              await resetGame();
              break;
            case 'PLAYER_KEY_PRESS':
              await handleKeyPress(userId, data.payload);
              break;
            case 'PLAYER_KEY_RELEASE':
              await handleKeyRelease(userId, data.payload);
              break;
          }
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });
    
    ws.on('close', async () => {
      if (userId) {
        storage.removeClient(userId);
        await removePlayer(userId);
      }
    });
  });
  
  // API routes
  app.post('/api/login', async (req: Request, res: Response) => {
    try {
      const result = loginUserSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: 'Invalid login data' });
      }
      
      const { username, password } = result.data;
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: 'Invalid username or password' });
      }
      
      // Return user without password
      const { password: _, ...safeUser } = user;
      return res.status(200).json(safeUser);
    } catch (error) {
      console.error('Login error:', error);
      return res.status(500).json({ message: 'An error occurred during login' });
    }
  });
  
  app.get('/api/users', async (_req: Request, res: Response) => {
    try {
      const users = await storage.getUsers();
      // Return users without passwords
      const safeUsers = users.map(({ password, ...user }) => user);
      return res.status(200).json(safeUsers);
    } catch (error) {
      console.error('Get users error:', error);
      return res.status(500).json({ message: 'An error occurred while fetching users' });
    }
  });

  return httpServer;
}
