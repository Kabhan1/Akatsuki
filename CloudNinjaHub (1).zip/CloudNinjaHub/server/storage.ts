import { users, type User, type InsertUser } from "@shared/schema";
import { customAlphabet } from "nanoid";
import { WebSocket } from "ws";

// Generate shorter IDs
const nanoid = customAlphabet("1234567890abcdef", 10);

// Character data
export const characters = [
  { 
    id: 'itachi', 
    name: 'Itachi', 
    password: 'sharingan', 
    avatar: 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMDAgMjAwIj48cmVjdCB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iIzMzMzMzMyIvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjgwIiByPSI0MCIgZmlsbD0iIzY2NjY2NiIvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjgwIiByPSIxNSIgZmlsbD0iI2ZmMDAwMCIvPjxwYXRoIGQ9Ik01MCwxMzBDNTAsMTgwIDE1MCwxODAgMTUwLDEzMCIgc3Ryb2tlPSIjNjY2NjY2IiBzdHJva2Utd2lkdGg9IjEwIiBmaWxsPSJ0cmFuc3BhcmVudCIvPjxwYXRoIGQ9Ik04MCw4MEg2MFYxMDBIMTQwVjgwSDEyMCIgZmlsbD0iIzQyNDI0MiIgLz48cG9seWdvbiBwb2ludHM9IjcwLDUwIDExMCw0MCAxMzAsNTAgMTQwLDkwIDYwLDkwIiBmaWxsPSIjMjIyMjIyIi8+PC9zdmc+'
  },
  { 
    id: 'kisame', 
    name: 'Kisame', 
    password: 'samehada', 
    avatar: 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMDAgMjAwIj48cmVjdCB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iIzMzMzM2NiIvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjgwIiByPSI0MCIgZmlsbD0iIzU1NjY5OSIvPjxwYXRoIGQ9Ik03MCw4MCA4MCw2NSA5MCw4MCAxMTAsODAgMTIwLDY1IDEzMCw4MCIgc3Ryb2tlPSIjM2EzYTdhIiBzdHJva2Utd2lkdGg9IjUiIGZpbGw9InRyYW5zcGFyZW50Ii8+PGNpcmNsZSBjeD0iODAiIGN5PSI3MCIgcj0iNSIgZmlsbD0id2hpdGUiLz48Y2lyY2xlIGN4PSIxMjAiIGN5PSI3MCIgcj0iNSIgZmlsbD0id2hpdGUiLz48cGF0aCBkPSJNNzAsMTAwQzgwLDEyMCAxMjAsMTIwIDEzMCwxMDAiIGZpbGw9InRyYW5zcGFyZW50IiBzdHJva2U9IiMzYTNhN2EiIHN0cm9rZS13aWR0aD0iNSIvPjxwYXRoIGQ9Ik01MCwxMzBDNTAsMTgwIDE1MCwxODAgMTUwLDEzMCIgc3Ryb2tlPSIjNTU2Njk5IiBzdHJva2Utd2lkdGg9IjEwIiBmaWxsPSJ0cmFuc3BhcmVudCIvPjwvc3ZnPg=='
  },
  { 
    id: 'deidara', 
    name: 'Deidara', 
    password: 'artisbang', 
    avatar: 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMDAgMjAwIj48cmVjdCB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iIzY2NjYzMyIvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjgwIiByPSI0MCIgZmlsbD0iIzk5OTk2NiIvPjxjaXJjbGUgY3g9IjgwIiBjeT0iNzAiIHI9IjUiIGZpbGw9IiM5OWNjZmYiLz48Y2lyY2xlIGN4PSIxMjAiIGN5PSI3MCIgcj0iNSIgZmlsbD0iIzk5Y2NmZiIvPjxwYXRoIGQ9Ik01MCwxMzBDNTAsMTgwIDE1MCwxODAgMTUwLDEzMCIgc3Ryb2tlPSIjOTk5OTY2IiBzdHJva2Utd2lkdGg9IjEwIiBmaWxsPSJ0cmFuc3BhcmVudCIvPjxwYXRoIGQ9Ik04MCwxMDBDOTAsMTE1IDExMCwxMTUgMTIwLDEwMCIgZmlsbD0idHJhbnNwYXJlbnQiIHN0cm9rZT0iIzY2NjYzMyIgc3Ryb2tlLXdpZHRoPSI1Ii8+PHBhdGggZD0iTTYwLDYwQzUwLDYwIDUwLDQwIDExMCw1MCAxNzAsNjAgMTUwLDYwIDE0MCw2MCIgZmlsbD0iI2ZmZmZjYyIgLz48L3N2Zz4='
  },
  { 
    id: 'tobi', 
    name: 'Tobi', 
    password: 'goodboy', 
    avatar: 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMDAgMjAwIj48cmVjdCB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iIzMzMzMzMyIvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjgwIiByPSI0MCIgZmlsbD0iIzY2MzMzMyIvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjgwIiByPSIzMCIgZmlsbD0iI2ZmOTkwMCIvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjgwIiByPSIyMCIgZmlsbD0iIzMzMzMzMyIvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjgwIiByPSIxMCIgZmlsbD0iI2ZmMDAwMCIvPjxwYXRoIGQ9Ik04MCwxMDVDOTAsMTIwIDExMCwxMjAgMTIwLDEwNSIgZmlsbD0idHJhbnNwYXJlbnQiIHN0cm9rZT0iIzMzMzMzMyIgc3Ryb2tlLXdpZHRoPSI1Ii8+PHBhdGggZD0iTTUwLDEzMEM1MCwxODAgMTUwLDE4MCAxNTAsMTMwIiBzdHJva2U9IiM2NjMzMzMiIHN0cm9rZS13aWR0aD0iMTAiIGZpbGw9InRyYW5zcGFyZW50Ii8+PC9zdmc+'
  }
];

export interface Client {
  id: number;
  ws: WebSocket;
}

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUsers(): Promise<User[]>;
  addClient(userId: number, ws: WebSocket): void;
  removeClient(userId: number): void;
  broadcastToAll(message: any): void;
  broadcastToOthers(excludeUserId: number, message: any): void;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private clients: Map<number, Client>;
  currentId: number;

  constructor() {
    this.users = new Map();
    this.clients = new Map();
    this.currentId = 1;
    
    // Pre-populate with the 4 Akatsuki members
    this.initializeUsers();
  }

  private async initializeUsers() {
    for (const character of characters) {
      await this.createUser({
        username: character.name,
        password: character.password,
        avatar: character.avatar,
        characterId: character.id
      });
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  addClient(userId: number, ws: WebSocket): void {
    this.clients.set(userId, { id: userId, ws });
  }

  removeClient(userId: number): void {
    this.clients.delete(userId);
  }

  broadcastToAll(message: any): void {
    this.clients.forEach(client => {
      if (client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(JSON.stringify(message));
      }
    });
  }

  broadcastToOthers(excludeUserId: number, message: any): void {
    this.clients.forEach(client => {
      if (client.id !== excludeUserId && client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(JSON.stringify(message));
      }
    });
  }
}

export const storage = new MemStorage();
