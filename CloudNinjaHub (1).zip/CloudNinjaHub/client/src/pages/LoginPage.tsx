import { useState } from "react";
import { AkatsukiLogo } from "@/components/AkatsukiLogo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { characters } from "@/lib/utils";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

export default function LoginPage() {
  const [selectedCharacter, setSelectedCharacter] = useState<string | null>(null);
  const [password, setPassword] = useState("");
  const { login, loading, error } = useAuth();
  const { toast } = useToast();

  const handleLogin = async () => {
    if (!selectedCharacter) {
      toast({
        title: "Selection Required",
        description: "Please select a character",
        variant: "destructive",
      });
      return;
    }

    const character = characters.find(c => c.id === selectedCharacter);
    if (!character) return;

    await login({
      username: character.name,
      password,
    });

    if (error) {
      toast({
        title: "Login Failed",
        description: "Incorrect password. Try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-background bg-opacity-95 p-4 akatsuki-cloud-bg">
      <div className="w-full max-w-md bg-card rounded-lg shadow-2xl overflow-hidden border-2 border-primary">
        <div className="p-6">
          <div className="flex justify-center mb-6">
            <AkatsukiLogo size="lg" />
          </div>

          <h1 className="text-2xl font-bold text-center mb-6">Akatsuki Login</h1>
          
          <div className="space-y-4">
            <div className="flex flex-wrap justify-center gap-4 mb-6">
              {characters.map((character) => (
                <div
                  key={character.id}
                  className={cn(
                    "cursor-pointer w-24 h-32 p-2 bg-muted rounded-lg flex flex-col items-center transition-all hover:bg-accent hover:scale-105",
                    selectedCharacter === character.id && "ring-2 ring-primary"
                  )}
                  onClick={() => setSelectedCharacter(character.id)}
                >
                  <img 
                    src={character.avatar} 
                    alt={character.name} 
                    className="w-14 h-14 rounded-full object-cover mb-2" 
                  />
                  <span className="text-sm font-semibold">{character.name}</span>
                </div>
              ))}
            </div>
            
            <div className="space-y-4">
              <div>
                <label htmlFor="password" className="block text-sm font-medium mb-1">Password</label>
                <Input 
                  type="password" 
                  id="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-muted"
                  placeholder="Enter your password" 
                />
              </div>
              
              <Button 
                disabled={!selectedCharacter || !password || loading}
                onClick={handleLogin}
                className="w-full bg-primary hover:bg-red-700"
              >
                {loading ? "Logging in..." : "Login"}
              </Button>
              
              {error && <p className="text-destructive text-sm text-center">Incorrect password. Try again.</p>}
            </div>
          </div>
        </div>
        
        <div className="px-6 py-3 bg-muted flex justify-between items-center text-xs text-muted-foreground">
          <span>Character passwords are required</span>
          <span>Akatsuki © Hidden Leaf</span>
        </div>
      </div>
    </div>
  );
}
