import { useEffect, useState } from "react";
import { Header } from "@/components/Header";
import { Navigation } from "@/components/Navigation";
import { ChatSection } from "@/components/ChatSection";
import { GameSection } from "@/components/GameSection";
import { useAuth } from "@/hooks/use-auth";
import { useWebSocket } from "@/lib/websocket";

export default function MainPage() {
  const [activeTab, setActiveTab] = useState<'chat' | 'game'>('chat');
  const { user } = useAuth();
  const { connect } = useWebSocket();

  // Connect to WebSocket when user logs in
  useEffect(() => {
    if (user) {
      connect(user.id);
    }
  }, [user, connect]);

  return (
    <div className="flex flex-col h-screen akatsuki-cloud-bg">
      <Header />
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
      
      <main className="flex-grow overflow-hidden">
        <div className="container mx-auto h-full">
          {activeTab === 'chat' ? (
            <ChatSection />
          ) : (
            <GameSection />
          )}
        </div>
      </main>
    </div>
  );
}
