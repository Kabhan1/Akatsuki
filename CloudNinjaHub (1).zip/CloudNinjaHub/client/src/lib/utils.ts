import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatTime(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

export const characters = [
  { 
    id: 'itachi', 
    name: 'Itachi', 
    password: 'sharingan', 
    avatar: 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMDAgMjAwIj48cmVjdCB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iIzMzMzMzMyIvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjgwIiByPSI0MCIgZmlsbD0iIzY2NjY2NiIvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjgwIiByPSIxNSIgZmlsbD0iI2ZmMDAwMCIvPjxwYXRoIGQ9Ik01MCwxMzBDNTAsMTgwIDE1MCwxODAgMTUwLDEzMCIgc3Ryb2tlPSIjNjY2NjY2IiBzdHJva2Utd2lkdGg9IjEwIiBmaWxsPSJ0cmFuc3BhcmVudCIvPjxwYXRoIGQ9Ik04MCw4MEg2MFYxMDBIMTQwVjgwSDEyMCIgZmlsbD0iIzQyNDI0MiIgLz48cG9seWdvbiBwb2ludHM9IjcwLDUwIDExMCw0MCAxMzAsNTAgMTQwLDkwIDYwLDkwIiBmaWxsPSIjMjIyMjIyIi8+PC9zdmc+'
  },
  { 
    id: 'kisame', 
    name: 'Kisame', 
    password: 'samehada', 
    avatar: 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMDAgMjAwIj48cmVjdCB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iIzMzMzM2NiIvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjgwIiByPSI0MCIgZmlsbD0iIzU1NjY5OSIvPjxwYXRoIGQ9Ik03MCw4MCA4MCw2NSA5MCw4MCAxMTAsODAgMTIwLDY1IDEzMCw4MCIgc3Ryb2tlPSIjM2EzYTdhIiBzdHJva2Utd2lkdGg9IjUiIGZpbGw9InRyYW5zcGFyZW50Ii8+PGNpcmNsZSBjeD0iODAiIGN5PSI3MCIgcj0iNSIgZmlsbD0id2hpdGUiLz48Y2lyY2xlIGN4PSIxMjAiIGN5PSI3MCIgcj0iNSIgZmlsbD0id2hpdGUiLz48cGF0aCBkPSJNNzAsMTAwQzgwLDEyMCAxMjAsMTIwIDEzMCwxMDAiIGZpbGw9InRyYW5zcGFyZW50IiBzdHJva2U9IiMzYTNhN2EiIHN0cm9rZS13aWR0aD0iNSIvPjxwYXRoIGQ9Ik01MCwxMzBDNTAsMTgwIDE1MCwxODAgMTUwLDEzMCIgc3Ryb2tlPSIjNTU2Njk5IiBzdHJva2Utd2lkdGg9IjEwIiBmaWxsPSJ0cmFuc3BhcmVudCIvPjwvc3ZnPg=='
  },
  { 
    id: 'deidara', 
    name: 'Deidara', 
    password: 'artisbang', 
    avatar: 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMDAgMjAwIj48cmVjdCB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iIzY2NjYzMyIvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjgwIiByPSI0MCIgZmlsbD0iIzk5OTk2NiIvPjxjaXJjbGUgY3g9IjgwIiBjeT0iNzAiIHI9IjUiIGZpbGw9IiM5OWNjZmYiLz48Y2lyY2xlIGN4PSIxMjAiIGN5PSI3MCIgcj0iNSIgZmlsbD0iIzk5Y2NmZiIvPjxwYXRoIGQ9Ik01MCwxMzBDNTAsMTgwIDE1MCwxODAgMTUwLDEzMCIgc3Ryb2tlPSIjOTk5OTY2IiBzdHJva2Utd2lkdGg9IjEwIiBmaWxsPSJ0cmFuc3BhcmVudCIvPjxwYXRoIGQ9Ik04MCwxMDBDOTAsMTE1IDExMCwxMTUgMTIwLDEwMCIgZmlsbD0idHJhbnNwYXJlbnQiIHN0cm9rZT0iIzY2NjYzMyIgc3Ryb2tlLXdpZHRoPSI1Ii8+PHBhdGggZD0iTTYwLDYwQzUwLDYwIDUwLDQwIDExMCw1MCAxNzAsNjAgMTUwLDYwIDE0MCw2MCIgZmlsbD0iI2ZmZmZjYyIgLz48L3N2Zz4='
  },
  { 
    id: 'tobi', 
    name: 'Tobi', 
    password: 'goodboy', 
    avatar: 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMDAgMjAwIj48cmVjdCB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iIzMzMzMzMyIvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjgwIiByPSI0MCIgZmlsbD0iIzY2MzMzMyIvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjgwIiByPSIzMCIgZmlsbD0iI2ZmOTkwMCIvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjgwIiByPSIyMCIgZmlsbD0iIzMzMzMzMyIvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjgwIiByPSIxMCIgZmlsbD0iI2ZmMDAwMCIvPjxwYXRoIGQ9Ik04MCwxMDVDOTAsMTIwIDExMCwxMjAgMTIwLDEwNSIgZmlsbD0idHJhbnNwYXJlbnQiIHN0cm9rZT0iIzMzMzMzMyIgc3Ryb2tlLXdpZHRoPSI1Ii8+PHBhdGggZD0iTTUwLDEzMEM1MCwxODAgMTUwLDE4MCAxNTAsMTMwIiBzdHJva2U9IiM2NjMzMzMiIHN0cm9rZS13aWR0aD0iMTAiIGZpbGw9InRyYW5zcGFyZW50Ii8+PC9zdmc+'
  }
];
