import { Player } from "@shared/schema";

// Calculate the position to move toward a particular coordinate
export function calculateMovement(
  player: Player,
  targetX: number,
  targetY: number,
  speed: number = 5
): { x: number; y: number } {
  // Calculate the direction vector
  const dx = targetX - player.x;
  const dy = targetY - player.y;
  
  // Calculate the distance
  const distance = Math.sqrt(dx * dx + dy * dy);
  
  // If we're already close to the target, just return the target coordinates
  if (distance < speed) {
    return { x: targetX, y: targetY };
  }
  
  // Normalize the direction vector and multiply by speed
  const normalizedDx = (dx / distance) * speed;
  const normalizedDy = (dy / distance) * speed;
  
  // Return the new position
  return {
    x: player.x + normalizedDx,
    y: player.y + normalizedDy
  };
}

// Check if two players are colliding
export function checkCollision(player1: Player, player2: Player, radius: number = 50): boolean {
  const dx = player1.x - player2.x;
  const dy = player1.y - player2.y;
  const distance = Math.sqrt(dx * dx + dy * dy);
  
  return distance < radius;
}

// Get a random position within the game area
export function getRandomPosition(width: number, height: number): { x: number; y: number } {
  return {
    x: Math.floor(Math.random() * (width - 100)) + 50,
    y: Math.floor(Math.random() * (height - 100)) + 50
  };
}
