import { create } from "zustand";
import { Message, GameState, WebSocketMessage } from "@shared/schema";

interface WebSocketState {
  socket: WebSocket | null;
  connected: boolean;
  messages: Message[];
  gameState: GameState;
  connect: (userId: number) => void;
  disconnect: () => void;
  sendMessage: (message: string) => void;
  sendPlayerMove: (x: number, y: number) => void;
  sendKeyPress: (key: string) => void;
  sendKeyRelease: (key: string) => void;
  startGame: () => void;
  resetGame: () => void;
}

export const useWebSocket = create<WebSocketState>((set, get) => ({
  socket: null,
  connected: false,
  messages: [],
  gameState: {
    players: [],
    platforms: [],
    gravity: 0.5,
    started: false,
    currentTagger: null
  },
  
  connect: (userId: number) => {
    // Close existing connection if any
    if (get().socket) {
      get().socket?.close();
    }
    
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const socket = new WebSocket(wsUrl);
    
    socket.onopen = () => {
      set({ socket, connected: true });
      
      // Send authentication message
      socket.send(JSON.stringify({
        type: 'AUTH',
        userId
      }));
    };
    
    socket.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data) as WebSocketMessage;
        
        switch (message.type) {
          case 'INITIAL_DATA':
            set({
              messages: message.payload.messages,
              gameState: message.payload.gameState
            });
            break;
          case 'CHAT_MESSAGE':
            set((state) => ({
              messages: [...state.messages, message.payload]
            }));
            break;
          case 'GAME_STATE':
            set({ gameState: message.payload });
            break;
          case 'USER_JOINED':
          case 'USER_LEFT':
          case 'PLAYER_TAGGED':
            // These events are handled by server-sent messages
            break;
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };
    
    socket.onclose = () => {
      set({ socket: null, connected: false });
    };
    
    socket.onerror = (error) => {
      console.error('WebSocket error:', error);
      set({ socket: null, connected: false });
    };
  },
  
  disconnect: () => {
    get().socket?.close();
    set({ socket: null, connected: false });
  },
  
  sendMessage: (text: string) => {
    if (!get().socket || !get().connected) return;
    
    get().socket!.send(JSON.stringify({
      type: 'CHAT_MESSAGE',
      payload: text
    }));
  },
  
  sendPlayerMove: (x: number, y: number) => {
    if (!get().socket || !get().connected) return;
    
    get().socket!.send(JSON.stringify({
      type: 'PLAYER_MOVE',
      payload: { x, y }
    }));
  },
  
  startGame: () => {
    if (!get().socket || !get().connected) return;
    
    get().socket!.send(JSON.stringify({
      type: 'GAME_START'
    }));
  },
  
  resetGame: () => {
    if (!get().socket || !get().connected) return;
    
    get().socket!.send(JSON.stringify({
      type: 'GAME_RESET'
    }));
  },
  
  sendKeyPress: (key: string) => {
    if (!get().socket || !get().connected) return;
    
    get().socket!.send(JSON.stringify({
      type: 'PLAYER_KEY_PRESS',
      payload: key
    }));
  },
  
  sendKeyRelease: (key: string) => {
    if (!get().socket || !get().connected) return;
    
    get().socket!.send(JSON.stringify({
      type: 'PLAYER_KEY_RELEASE',
      payload: key
    }));
  }
}));
