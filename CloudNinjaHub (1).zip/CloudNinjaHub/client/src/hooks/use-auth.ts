import { create } from "zustand";
import { apiRequest } from "@/lib/queryClient";
import { LoginUser } from "@shared/schema";

interface User {
  id: number;
  username: string;
  avatar: string;
  characterId: string;
}

interface AuthState {
  user: User | null;
  loading: boolean;
  error: string | null;
  login: (credentials: LoginUser) => Promise<void>;
  logout: () => void;
}

export const useAuth = create<AuthState>((set) => ({
  user: null,
  loading: false,
  error: null,
  
  login: async (credentials: LoginUser) => {
    try {
      set({ loading: true, error: null });
      const response = await apiRequest("POST", "/api/login", credentials);
      const user = await response.json();
      set({ user, loading: false });
    } catch (error) {
      set({ 
        loading: false, 
        error: error instanceof Error ? error.message : "Login failed" 
      });
    }
  },
  
  logout: () => {
    set({ user: null });
  }
}));
