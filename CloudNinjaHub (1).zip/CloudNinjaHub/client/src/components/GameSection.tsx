import { Button } from "./ui/button";
import { GameCanvas } from "./GameCanvas";
import { useWebSocket } from "@/lib/websocket";
import { Play, RotateCcw } from "lucide-react";

export function GameSection() {
  const { gameState, startGame, resetGame } = useWebSocket();
  
  const taggerName = gameState.currentTagger !== null 
    ? gameState.players.find(p => p.id === gameState.currentTagger)?.username 
    : "None";

  return (
    <section className="h-full p-4">
      <div className="bg-card rounded-lg border border-border h-full flex flex-col">
        <div className="p-4 border-b border-border">
          <h2 className="text-xl font-bold">Akatsuki Tag Game</h2>
          <p className="text-muted-foreground text-sm">
            Use WASD keys to move and jump. Tag other players to earn points!
          </p>
        </div>
        
        {/* Game Status */}
        <div className="flex items-center justify-between px-4 py-2 bg-muted">
          <div className="flex space-x-4">
            {gameState.players.map(player => (
              <div className="flex items-center" key={player.id}>
                <div className="w-4 h-4 rounded-full bg-green-500 mr-2"></div>
                <span className="text-sm font-medium">
                  {player.username}: {player.points} pts
                </span>
              </div>
            ))}
          </div>
          <div>
            <span className="text-sm font-medium">
              Current Tagger: <span className="text-primary">{taggerName}</span>
            </span>
          </div>
        </div>
        
        {/* Game Canvas */}
        <div className="flex-grow relative overflow-hidden bg-background border border-border m-2 rounded-md">
          <GameCanvas />
          
          {/* Game Instructions */}
          <div className="absolute bottom-0 left-0 right-0 bg-card bg-opacity-70 p-2 text-center">
            <p className="text-sm">
              Use <span className="font-bold">W</span> to jump, <span className="font-bold">A/D</span> to move left/right. 
              Tag others by moving close to them when you're "it".
            </p>
          </div>
        </div>
        
        {/* Game Controls */}
        <div className="p-3 border-t border-border flex justify-center">
          <Button
            onClick={startGame}
            disabled={gameState.started || gameState.players.length < 2}
            className="px-4 py-2 mr-2 bg-primary hover:bg-red-700"
          >
            <Play className="mr-2 h-4 w-4" /> Start Game
          </Button>
          <Button
            onClick={resetGame}
            variant="outline"
            className="px-4 py-2"
          >
            <RotateCcw className="mr-2 h-4 w-4" /> Reset
          </Button>
        </div>
      </div>
    </section>
  );
}
