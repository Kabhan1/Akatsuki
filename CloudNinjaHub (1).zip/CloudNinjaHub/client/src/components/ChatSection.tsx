import { useState, useRef, useEffect } from "react";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { useWebSocket } from "@/lib/websocket";
import { useAuth } from "@/hooks/use-auth";
import { formatTime } from "@/lib/utils";
import { Send } from "lucide-react";
import { ScrollArea } from "./ui/scroll-area";

export function ChatSection() {
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { messages, sendMessage } = useWebSocket();
  const { user } = useAuth();

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = () => {
    if (message.trim() && user) {
      sendMessage(message);
      setMessage("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSendMessage();
    }
  };

  return (
    <section className="flex flex-col h-full">
      <ScrollArea className="p-4 flex-grow">
        <div className="space-y-4">
          {messages.map((msg) => {
            if (msg.isSystem) {
              return (
                <div key={msg.id} className="flex justify-center my-4">
                  <div className="bg-muted rounded-lg p-3 max-w-sm text-center">
                    <p className="text-muted-foreground">{msg.text}</p>
                  </div>
                </div>
              );
            }

            const isCurrentUser = user && msg.sender === user.username;
            
            return isCurrentUser ? (
              <div key={msg.id} className="flex items-end justify-end">
                <div className="bg-primary rounded-lg p-3 max-w-xs sm:max-w-md">
                  <p>{msg.text}</p>
                  <div className="text-right text-xs text-primary-foreground/70 mt-1">
                    {formatTime(msg.timestamp)}
                  </div>
                </div>
              </div>
            ) : (
              <div key={msg.id} className="flex items-end">
                <img 
                  src={msg.senderAvatar} 
                  className="w-8 h-8 rounded-full mr-2" 
                  alt={msg.senderName}
                />
                <div className="bg-muted rounded-lg p-3 max-w-xs sm:max-w-md">
                  <div className="font-semibold text-xs text-muted-foreground mb-1">{msg.senderName}</div>
                  <p>{msg.text}</p>
                  <div className="text-right text-xs text-muted-foreground/70 mt-1">
                    {formatTime(msg.timestamp)}
                  </div>
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>
      
      <div className="p-4 border-t border-border bg-card">
        <div className="flex">
          <Input
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type your message..."
            className="flex-grow rounded-r-none bg-muted"
          />
          <Button
            onClick={handleSendMessage}
            className="bg-primary hover:bg-red-700 text-white rounded-l-none"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </section>
  );
}
