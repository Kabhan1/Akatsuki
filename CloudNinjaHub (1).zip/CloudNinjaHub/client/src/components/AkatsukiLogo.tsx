import { cn } from "@/lib/utils";

interface AkatsukiLogoProps {
  size?: "sm" | "md" | "lg";
  className?: string;
}

export function AkatsukiLogo({ size = "md", className }: AkatsukiLogoProps) {
  const sizeClasses = {
    sm: "w-10 h-10",
    md: "w-16 h-16",
    lg: "w-20 h-20",
  };

  const innerSizeClasses = {
    sm: "w-8 h-8",
    md: "w-12 h-12",
    lg: "w-16 h-16",
  };

  const textSizeClasses = {
    sm: "text-lg",
    md: "text-2xl",
    lg: "text-3xl",
  };

  return (
    <div className={cn("rounded-full bg-primary flex items-center justify-center", sizeClasses[size], className)}>
      <div className={cn("rounded-full bg-background flex items-center justify-center", innerSizeClasses[size])}>
        <span className={cn("text-primary font-bold", textSizeClasses[size])}>赤</span>
      </div>
    </div>
  );
}
