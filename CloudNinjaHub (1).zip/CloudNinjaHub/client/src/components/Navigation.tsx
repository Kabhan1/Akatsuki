import { cn } from "@/lib/utils";
import { MessageSquare, Gamepad2 } from "lucide-react";

interface NavigationProps {
  activeTab: 'chat' | 'game';
  onTabChange: (tab: 'chat' | 'game') => void;
}

export function Navigation({ activeTab, onTabChange }: NavigationProps) {
  return (
    <div className="bg-card border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex">
          <button 
            className={cn(
              "px-4 py-2 font-medium text-center border-b-2 focus:outline-none flex items-center",
              activeTab === 'chat' 
                ? "border-primary" 
                : "border-transparent hover:border-muted"
            )}
            onClick={() => onTabChange('chat')}
          >
            <MessageSquare className="mr-2 h-4 w-4" />
            Chat
          </button>
          <button 
            className={cn(
              "px-4 py-2 font-medium text-center border-b-2 focus:outline-none flex items-center",
              activeTab === 'game' 
                ? "border-primary" 
                : "border-transparent hover:border-muted"
            )}
            onClick={() => onTabChange('game')}
          >
            <Gamepad2 className="mr-2 h-4 w-4" />
            Tag Game
          </button>
        </div>
      </div>
    </div>
  );
}
