import { AkatsukiLogo } from "./AkatsukiLogo";
import { Button } from "./ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useWebSocket } from "@/lib/websocket";

export function Header() {
  const { user, logout } = useAuth();
  const { disconnect } = useWebSocket();

  const handleLogout = () => {
    disconnect();
    logout();
  };

  return (
    <header className="bg-card border-b border-primary shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <AkatsukiLogo size="sm" className="mr-3" />
          <h1 className="text-xl font-bold">Akatsuki Hideout</h1>
        </div>
        
        <div className="flex items-center space-x-4">
          {user && (
            <>
              <div className="flex items-center">
                <img 
                  src={user.avatar} 
                  alt={user.username} 
                  className="w-8 h-8 rounded-full border border-primary"
                />
                <span className="ml-2 font-semibold">{user.username}</span>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleLogout}
                className="text-sm px-3 py-1"
              >
                Logout
              </Button>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
