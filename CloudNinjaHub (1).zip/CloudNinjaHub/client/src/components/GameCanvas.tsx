import { useEffect, useRef } from "react";
import { useWebSocket } from "@/lib/websocket";
import { useAuth } from "@/hooks/use-auth";
import { Platform } from "@shared/schema";

export function GameCanvas() {
  const { gameState, sendPlayerMove, sendKeyPress, sendKeyRelease } = useWebSocket();
  const { user } = useAuth();
  const canvasRef = useRef<HTMLDivElement>(null);

  // Set up keyboard controls
  useEffect(() => {
    if (!user) return;
    
    const handleKeyDown = (e: KeyboardEvent) => {
      // Only handle WASD keys
      if (['w', 'a', 's', 'd'].includes(e.key.toLowerCase())) {
        sendKeyPress(e.key.toLowerCase());
      }
    };
    
    const handleKeyUp = (e: KeyboardEvent) => {
      // Only handle WASD keys
      if (['w', 'a', 's', 'd'].includes(e.key.toLowerCase())) {
        sendKeyRelease(e.key.toLowerCase());
      }
    };
    
    // Add event listeners
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    
    // Clean up event listeners
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [user, sendKeyPress, sendKeyRelease]);

  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!canvasRef.current || !gameState.started || !user) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    // Send movement command to server (mostly for debugging since we now use WASD)
    sendPlayerMove(x, y);
  };

  return (
    <div 
      ref={canvasRef}
      className="absolute inset-0 akatsuki-cloud-bg"
      onClick={handleCanvasClick}
    >
      {/* Platforms */}
      {gameState.platforms.map((platform: Platform, index: number) => (
        <div
          key={index}
          className="absolute bg-primary-foreground/80 rounded"
          style={{
            left: `${platform.x}px`,
            top: `${platform.y}px`,
            width: `${platform.width}px`,
            height: `${platform.height}px`
          }}
        ></div>
      ))}
      
      {/* Player Avatars */}
      {gameState.players.map(player => (
        <div 
          key={player.id}
          className="absolute player-avatar transition-transform"
          style={{ 
            left: `${player.x}px`, 
            top: `${player.y}px`,
            transform: player.direction === 'left' ? 'scaleX(-1)' : 'scaleX(1)'
          }}
        >
          <div className="relative">
            <img 
              src={player.avatar} 
              className={`w-12 h-12 rounded-full border-2 ${player.isIt ? 'border-primary' : 'border-transparent'}`}
              alt={player.username} 
            />
            <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-green-500 border border-card"></span>
            {player.isIt && (
              <div 
                className="tag-area" 
                style={{ 
                  backgroundColor: 'hsl(var(--primary))',
                }}
              ></div>
            )}
          </div>
          <div className="text-center text-xs mt-1 whitespace-nowrap">
            {player.username} {player.points > 0 ? `(${player.points})` : ''}
          </div>
        </div>
      ))}
      
      {/* Game instructions */}
      <div className="absolute bottom-4 left-4 bg-background/80 p-2 rounded text-sm">
        <p>Use <span className="font-bold">W A S D</span> keys to move your character.</p>
        <p>Jump with <span className="font-bold">W</span>, move left/right with <span className="font-bold">A/D</span>.</p>
        {gameState.started && (
          <p>{gameState.currentTagger ? `${gameState.players.find(p => p.id === gameState.currentTagger)?.username} is IT!` : 'Game in progress!'}</p>
        )}
      </div>
    </div>
  );
}
