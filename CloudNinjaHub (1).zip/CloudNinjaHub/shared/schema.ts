import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  avatar: text("avatar").notNull(),
  characterId: text("character_id").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  avatar: true,
  characterId: true,
});

export const loginUserSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(1),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type LoginUser = z.infer<typeof loginUserSchema>;
export type User = typeof users.$inferSelect;

// Message types
export interface Message {
  id: string;
  sender: string;
  senderName: string;
  senderAvatar: string;
  text: string;
  timestamp: string;
  isSystem?: boolean;
}

// Game types
export interface Player {
  id: number;
  username: string;
  characterId: string;
  avatar: string;
  x: number;
  y: number;
  velocityY: number;
  velocityX: number;
  isJumping: boolean;
  direction: 'left' | 'right' | 'idle';
  points: number;
  isIt: boolean;
}

export interface Platform {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface GameState {
  players: Player[];
  platforms: Platform[];
  gravity: number;
  started: boolean;
  currentTagger: number | null;
}

// WebSocket message types
export type WebSocketMessageType = 
  | 'CHAT_MESSAGE' 
  | 'USER_JOINED' 
  | 'USER_LEFT' 
  | 'GAME_STATE' 
  | 'PLAYER_MOVE' 
  | 'PLAYER_KEY_PRESS'
  | 'PLAYER_KEY_RELEASE'
  | 'GAME_START' 
  | 'GAME_RESET'
  | 'PLAYER_TAGGED'
  | 'INITIAL_DATA'
  | 'AUTH';

export interface WebSocketMessage {
  type: WebSocketMessageType;
  payload: any;
}
